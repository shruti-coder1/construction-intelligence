import json
import os
from typing import Optional
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from starlette.concurrency import run_in_threadpool

from . import llm, mocks, prompts
from .schemas import *
from .weather import get_weather

app = FastAPI(title="Multimodal Construction Intelligence Platform", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:5173").split(","),
                   allow_methods=["*"], allow_headers=["*"])

ALLOWED = {"image/jpeg", "image/png", "image/webp"}
MAX_BYTES = 8 * 1024 * 1024


async def read_image(f: Optional[UploadFile], required: bool = True):
    if f is None or not f.filename:
        if required:
            raise HTTPException(400, "Please upload a site photo (JPG, PNG or WebP).")
        return None, None
    if f.content_type not in ALLOWED:
        raise HTTPException(415, "Unsupported file type. Use JPG, PNG or WebP.")
    data = await f.read()
    if not data:
        raise HTTPException(400, "The uploaded file is empty.")
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "Image is larger than 8 MB.")
    return data, f.content_type


@app.get("/api/health")
def health():
    return {"status": "ok", "mode": "demo" if llm.demo_mode() else "live"}


@app.post("/api/safety", response_model=SafetyReport)
async def safety(image: UploadFile = File(...), context: str = Form("")):
    data, mime = await read_image(image)
    r = await run_in_threadpool(llm.generate, prompts.SAFETY.format(context=context or "none"),
                                SafetyReport, mocks.safety(), data, mime)
    r.safety_score = max(0, min(100, r.safety_score))
    return r


@app.post("/api/cracks", response_model=CrackReport)
async def cracks(image: UploadFile = File(...), context: str = Form("")):
    data, mime = await read_image(image)
    return await run_in_threadpool(llm.generate, prompts.CRACK.format(context=context or "none"),
                                   CrackReport, mocks.cracks(), data, mime)


@app.post("/api/valuation", response_model=ValuationReport)
async def valuation(req: ValuationRequest):
    if req.area_sqft <= 0:
        raise HTTPException(422, "Area must be greater than zero.")
    d = req.model_dump()
    return await run_in_threadpool(llm.generate, prompts.VALUATION.format(req=json.dumps(d)),
                                   ValuationReport, mocks.valuation(d))


@app.post("/api/planning", response_model=PlanReport)
async def planning(req: PlanRequest):
    if req.built_up_area_sqft <= 0 or req.duration_months <= 0:
        raise HTTPException(422, "Area and duration must be greater than zero.")
    d = req.model_dump()
    return await run_in_threadpool(llm.generate, prompts.PLAN.format(req=json.dumps(d)),
                                   PlanReport, mocks.plan(d))


@app.post("/api/assistant", response_model=DailyReport)
async def assistant(site_name: str = Form(...), date: str = Form(""), work_done: str = Form(...),
                    workers_present: int = Form(0), issues: str = Form(""),
                    image: Optional[UploadFile] = File(None)):
    data, mime = await read_image(image, required=False)
    d = dict(site_name=site_name, date=date, work_done=work_done, workers_present=workers_present, issues=issues)
    return await run_in_threadpool(llm.generate, prompts.DAILY.format(req=json.dumps(d)),
                                   DailyReport, mocks.daily(d), data, mime)


@app.post("/api/weather")
async def weather(req: WeatherRequest):
    w = await run_in_threadpool(get_weather, req.city)
    adv = await run_in_threadpool(
        llm.generate, prompts.WEATHER.format(city=w["location"], weather=json.dumps(w), activity=req.activity or "general"),
        WeatherAdvisory, mocks.weather_advisory(w))
    return {**w, "advisory": adv.model_dump()}


@app.post("/api/knowledge", response_model=KnowledgeAnswer)
async def knowledge(req: KnowledgeRequest):
    if not req.question.strip():
        raise HTTPException(422, "Ask a question first.")
    hist = "\n".join(f"{t.role}: {t.content}" for t in req.history[-8:]) or "(none)"
    return await run_in_threadpool(llm.generate, prompts.KNOWLEDGE.format(history=hist, question=req.question),
                                   KnowledgeAnswer, mocks.knowledge(req.question))
