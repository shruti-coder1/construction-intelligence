SYSTEM = (
    "You are a senior civil/structural engineer and construction manager advising "
    "site teams in India. Be specific, practical and conservative about safety. "
    "Use INR for money and sq ft for area unless told otherwise. "
    "Respond ONLY with JSON that matches the provided schema; no markdown, no prose outside JSON. "
    "For image findings, state what is visible and recommend verification by a licensed engineer "
    "when risk is medium or higher."
)

SAFETY = ("Inspect this construction site photo for safety. Check PPE (helmets, vests, boots, harness, "
          "gloves), working at height, edge protection, scaffolding, excavations, electrical hazards, "
          "housekeeping, machinery and exclusion zones. Score 0-100 (100 = very safe). "
          "Extra context from the user: {context}")

CRACK = ("Analyse this photo of a crack in a building element. Classify the crack type, estimate width in mm, "
         "identify the affected element, probable causes, structural risk, and repairs (specific materials/"
         "methods) with urgency. If no crack is visible set crack_detected=false, crack_type='none', "
         "estimated_width_mm=0. Extra context: {context}")

VALUATION = ("Estimate the market value of this property in the Indian real estate market.\n{req}\n"
             "Give a point estimate, a realistic low-high range, price per sq ft, the main value drivers "
             "(positive/neutral/negative), and a short market outlook. Make estimated_value_inr consistent "
             "with price_per_sqft_inr x area.")

PLAN = ("Create a construction project plan.\n{req}\n"
        "Provide sequential phases (site prep through finishing/handover) with tasks and milestones, a cost "
        "breakdown whose percents sum to 100 and amounts sum to the total estimated cost, major material "
        "quantities, and key risks with mitigations. Compare estimate to budget in budget_status and make "
        "the duration consistent with the requested months.")

DAILY = ("Turn these site notes into a structured daily site report.\n{req}\n"
         "If a site photo is attached, use it to add progress observations and safety notes.")

WEATHER = ("Weather data for {city}:\n{weather}\nPlanned activity: {activity}\n"
           "Give a construction-focused advisory for the next days (concreting, masonry, crane/lifting, "
           "excavation, roofing, painting, curing).")

KNOWLEDGE = ("Answer this construction question clearly for a site engineer. Include standards/codes "
             "(e.g. IS codes) only when you are confident.\nConversation so far:\n{history}\nQuestion: {question}")
