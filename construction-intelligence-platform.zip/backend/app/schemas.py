"""Strict JSON contracts. The LLM is forced to emit these shapes and the
frontend renders them, so both sides stay stable. (No defaults/constraints
on LLM models: keeps the Gemini response_schema simple and portable.)"""
from typing import List, Literal
from pydantic import BaseModel

Severity = Literal["low", "medium", "high", "critical"]


# ---------- 1. Site safety ----------
class Violation(BaseModel):
    issue: str
    severity: Severity
    location: str
    recommendation: str

class SafetyReport(BaseModel):
    overall_risk: Severity
    safety_score: int  # 0-100, higher is safer
    summary: str
    ppe_detected: List[str]
    violations: List[Violation]
    recommendations: List[str]


# ---------- 2. Crack detection ----------
class CrackReport(BaseModel):
    crack_detected: bool
    crack_type: str  # hairline, shrinkage, settlement, structural, diagonal, none
    severity: Severity
    estimated_width_mm: float
    affected_element: str
    probable_causes: List[str]
    structural_risk: str
    repair_recommendations: List[str]
    urgency: str
    summary: str


# ---------- 3. Valuation ----------
class ValuationRequest(BaseModel):
    location: str
    property_type: str
    area_sqft: float
    bedrooms: int
    age_years: int
    condition: str
    amenities: List[str]

class ValueFactor(BaseModel):
    name: str
    impact: Literal["positive", "neutral", "negative"]
    explanation: str

class ValuationReport(BaseModel):
    estimated_value_inr: float
    price_per_sqft_inr: float
    range_low_inr: float
    range_high_inr: float
    confidence: Literal["low", "medium", "high"]
    factors: List[ValueFactor]
    market_outlook: str
    summary: str


# ---------- 4. Project planning ----------
class PlanRequest(BaseModel):
    project_name: str
    project_type: str
    location: str
    built_up_area_sqft: float
    floors: int
    budget_inr: float
    duration_months: int
    notes: str

class Phase(BaseModel):
    name: str
    duration_weeks: int
    tasks: List[str]
    milestone: str

class CostItem(BaseModel):
    category: str
    percent: float
    amount_inr: float

class Material(BaseModel):
    item: str
    quantity: float
    unit: str

class Risk(BaseModel):
    risk: str
    mitigation: str

class PlanReport(BaseModel):
    summary: str
    total_duration_weeks: int
    total_estimated_cost_inr: float
    budget_status: str
    phases: List[Phase]
    cost_breakdown: List[CostItem]
    materials: List[Material]
    risks: List[Risk]


# ---------- 5. Daily site assistant ----------
class DailyReport(BaseModel):
    summary: str
    progress_estimate_percent: int
    completed_items: List[str]
    pending_items: List[str]
    issues: List[str]
    safety_notes: List[str]
    resource_needs: List[str]
    next_day_plan: List[str]


# ---------- 6. Weather advisory ----------
class WeatherRequest(BaseModel):
    city: str
    activity: str = ""

class WeatherAdvisory(BaseModel):
    work_suitability: Literal["good", "caution", "poor"]
    risk_level: Severity
    summary: str
    recommended_activities: List[str]
    activities_to_avoid: List[str]
    precautions: List[str]


# ---------- 7. Knowledge assistant ----------
class ChatTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str

class KnowledgeRequest(BaseModel):
    question: str
    history: List[ChatTurn] = []

class KnowledgeAnswer(BaseModel):
    answer: str
    key_points: List[str]
    related_topics: List[str]
    caution: str
