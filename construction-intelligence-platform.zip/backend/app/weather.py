import httpx
from fastapi import HTTPException

CODES = {0: "Clear", 1: "Mostly clear", 2: "Partly cloudy", 3: "Overcast", 45: "Fog", 48: "Fog",
         51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle", 61: "Light rain", 63: "Rain",
         65: "Heavy rain", 80: "Rain showers", 81: "Rain showers", 82: "Violent showers",
         95: "Thunderstorm", 96: "Thunderstorm, hail", 99: "Thunderstorm, hail"}


def get_weather(city: str) -> dict:
    try:
        with httpx.Client(timeout=12) as c:
            g = c.get("https://geocoding-api.open-meteo.com/v1/search",
                      params={"name": city, "count": 1}).json()
            if not g.get("results"):
                raise HTTPException(404, f"Could not find a place called '{city}'.")
            p = g["results"][0]
            f = c.get("https://api.open-meteo.com/v1/forecast", params={
                "latitude": p["latitude"], "longitude": p["longitude"], "timezone": "auto",
                "forecast_days": 5,
                "current": "temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,weather_code",
                "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max",
            }).json()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f"Weather service unavailable: {e}")
    cur, d = f["current"], f["daily"]
    return {
        "location": ", ".join(x for x in (p["name"], p.get("admin1"), p.get("country")) if x),
        "current": {"temperature_c": cur["temperature_2m"], "humidity_pct": cur["relative_humidity_2m"],
                    "precipitation_mm": cur["precipitation"], "wind_kmh": cur["wind_speed_10m"],
                    "condition": CODES.get(cur["weather_code"], "Unknown")},
        "daily": [{"date": d["time"][i], "condition": CODES.get(d["weather_code"][i], "Unknown"),
                   "temp_max_c": d["temperature_2m_max"][i], "temp_min_c": d["temperature_2m_min"][i],
                   "rain_mm": d["precipitation_sum"][i], "wind_max_kmh": d["wind_speed_10m_max"][i]}
                  for i in range(len(d["time"]))],
    }
