"""Demo-mode responses so the whole app runs without an API key."""

def safety():
    return {"overall_risk": "high", "safety_score": 52,
            "summary": "DEMO: Workers are active at height with partial PPE and incomplete edge protection.",
            "ppe_detected": ["Hard hat", "Safety boots"],
            "violations": [
                {"issue": "No high-visibility vest on workers", "severity": "medium", "location": "Ground level",
                 "recommendation": "Make hi-vis vests mandatory at site entry."},
                {"issue": "Missing guardrail on upper slab edge", "severity": "critical", "location": "Upper floor edge",
                 "recommendation": "Install 1.0 m guardrail with mid-rail and toe board before work resumes."},
                {"issue": "Loose materials near walkway", "severity": "low", "location": "Material yard",
                 "recommendation": "Stack and cordon materials; keep 1 m clear walkway."}],
            "recommendations": ["Hold a toolbox talk on work at height", "Daily PPE checks at the gate",
                                "Inspect scaffolding and tag it before each shift"]}

def cracks():
    return {"crack_detected": True, "crack_type": "diagonal", "severity": "medium", "estimated_width_mm": 1.5,
            "affected_element": "Brick masonry wall near opening",
            "probable_causes": ["Differential settlement", "Stress concentration at window corner", "Thermal movement"],
            "structural_risk": "DEMO: Possible minor settlement; likely non-structural plaster/masonry cracking but needs monitoring.",
            "repair_recommendations": ["Install crack gauge/tell-tales and monitor for 4 weeks",
                                       "Rake out, fill with polymer-modified mortar and apply fibre mesh before re-plastering",
                                       "Check foundation drainage near this wall"],
            "urgency": "Inspect within 2 weeks",
            "summary": "DEMO: A diagonal crack of about 1.5 mm runs from a corner of an opening."}

def valuation(r):
    ppsf = 7500 * (1 - min(r["age_years"], 40) * 0.005) * (1.1 if r["condition"].lower() == "excellent" else 1.0)
    ppsf += 150 * len(r["amenities"])
    v = round(ppsf * r["area_sqft"], -3)
    return {"estimated_value_inr": v, "price_per_sqft_inr": round(ppsf),
            "range_low_inr": round(v * 0.9, -3), "range_high_inr": round(v * 1.1, -3), "confidence": "medium",
            "factors": [
                {"name": "Location", "impact": "positive", "explanation": f"{r['location']} has steady demand."},
                {"name": "Age", "impact": "negative" if r["age_years"] > 15 else "neutral",
                 "explanation": f"Building is {r['age_years']} years old."},
                {"name": "Amenities", "impact": "positive" if r["amenities"] else "neutral",
                 "explanation": f"{len(r['amenities'])} amenities listed."}],
            "market_outlook": "DEMO: Stable with modest annual appreciation.",
            "summary": "DEMO estimate from a simple heuristic; set GEMINI_API_KEY for AI valuation."}

def plan(r):
    total = r["built_up_area_sqft"] * 2200
    weeks = r["duration_months"] * 4
    split = [("Site preparation & foundation", 20), ("Structure (RCC frame)", 30), ("Masonry & plastering", 15),
             ("MEP", 15), ("Finishing & handover", 20)]
    cost_split = [("Foundation", 18), ("Structure", 30), ("Masonry & plaster", 14), ("MEP", 16), ("Finishing", 22)]
    a = r["built_up_area_sqft"]
    return {"summary": f"DEMO plan for {r['project_name']} ({r['project_type']}).",
            "total_duration_weeks": weeks, "total_estimated_cost_inr": total,
            "budget_status": "Within budget" if total <= r["budget_inr"] else "Over budget; consider value engineering",
            "phases": [{"name": n, "duration_weeks": max(1, round(weeks * p / 100)),
                        "tasks": ["Mobilise crew and materials", "Execute and inspect work", "Quality sign-off"],
                        "milestone": f"{n} complete"} for n, p in split],
            "cost_breakdown": [{"category": c, "percent": p, "amount_inr": round(total * p / 100)} for c, p in cost_split],
            "materials": [{"item": "Cement", "quantity": round(a * 0.4), "unit": "bags"},
                          {"item": "Steel (TMT)", "quantity": round(a * 4 / 1000, 1), "unit": "tonnes"},
                          {"item": "Sand", "quantity": round(a * 1.2), "unit": "cu ft"},
                          {"item": "Bricks", "quantity": round(a * 8), "unit": "nos"}],
            "risks": [{"risk": "Monsoon delays", "mitigation": "Schedule excavation and concreting outside heavy rain"},
                      {"risk": "Material price escalation", "mitigation": "Bulk-purchase steel and cement early"}]}

def daily(r):
    return {"summary": f"DEMO: Report for {r['site_name']} on {r['date']} with {r['workers_present']} workers.",
            "progress_estimate_percent": 4,
            "completed_items": [s.strip() for s in r["work_done"].split(".") if s.strip()][:5] or ["Routine work"],
            "pending_items": ["Curing checks", "Material reconciliation"],
            "issues": [r["issues"]] if r["issues"] else [],
            "safety_notes": ["Conduct toolbox talk", "Verify PPE at start of shift"],
            "resource_needs": ["Confirm tomorrow's material delivery"],
            "next_day_plan": ["Continue planned activity", "Quality inspection", "Update progress photos"]}

def weather_advisory(w):
    rain = max(d["rain_mm"] for d in w["daily"][:3]); wind = max(d["wind_max_kmh"] for d in w["daily"][:3])
    poor = rain > 15 or wind > 40
    caution = rain > 3 or wind > 25 or w["current"]["temperature_c"] > 38
    return {"work_suitability": "poor" if poor else "caution" if caution else "good",
            "risk_level": "high" if poor else "medium" if caution else "low",
            "summary": f"Rule-based advisory: up to {rain:.0f} mm rain and {wind:.0f} km/h wind in the next 3 days.",
            "recommended_activities": ["Indoor finishing", "Rebar tying", "Material inspection"] if caution else
                                      ["Concreting", "Masonry", "Excavation"],
            "activities_to_avoid": ["Concrete pours", "Crane lifts", "Exterior painting"] if caution else [],
            "precautions": ["Cover cement and steel", "Secure scaffolding and loose sheets", "Keep drainage clear"]}

def knowledge(q):
    return {"answer": f"DEMO answer for: '{q}'. Set GEMINI_API_KEY to get real AI answers on construction topics.",
            "key_points": ["Follow the relevant IS code", "Verify with a licensed engineer"],
            "related_topics": ["Concrete curing", "Reinforcement detailing"],
            "caution": "General guidance only; not a substitute for a site-specific engineering design."}
