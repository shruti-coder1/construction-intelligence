import os
from typing import Optional, Type, TypeVar
from fastapi import HTTPException
from pydantic import BaseModel, ValidationError
from .prompts import SYSTEM

T = TypeVar("T", bound=BaseModel)


def demo_mode() -> bool:
    return not os.getenv("GEMINI_API_KEY")


def generate(prompt: str, schema: Type[T], mock: dict, image: Optional[bytes] = None,
             mime: Optional[str] = None) -> T:
    """Call Gemini with a response schema. Falls back to `mock` when no API key is set."""
    if demo_mode():
        return schema.model_validate(mock)

    from google import genai
    from google.genai import types

    client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
    parts = []
    if image:
        parts.append(types.Part.from_bytes(data=image, mime_type=mime or "image/jpeg"))
    parts.append(prompt)
    config = types.GenerateContentConfig(
        system_instruction=SYSTEM, response_mime_type="application/json",
        response_schema=schema, temperature=0.3)

    last_err = None
    for _ in range(2):  # one retry on malformed output
        try:
            resp = client.models.generate_content(
                model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"), contents=parts, config=config)
            return schema.model_validate_json(resp.text)
        except ValidationError as e:
            last_err = e
        except Exception as e:  # network / quota / auth
            raise HTTPException(502, f"AI service error: {e}")
    raise HTTPException(502, f"AI returned invalid JSON: {last_err}")
