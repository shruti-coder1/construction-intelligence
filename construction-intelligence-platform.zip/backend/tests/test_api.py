import os
os.environ.pop("GEMINI_API_KEY", None)  # force demo mode
from fastapi.testclient import TestClient
from app.main import app

c = TestClient(app)
PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 50


def test_health():
    assert c.get("/api/health").json()["mode"] == "demo"

def test_safety_and_cracks():
    for ep in ("safety", "cracks"):
        r = c.post(f"/api/{ep}", files={"image": ("a.png", PNG, "image/png")})
        assert r.status_code == 200, r.text

def test_rejects_bad_upload():
    assert c.post("/api/safety", files={"image": ("a.txt", b"x", "text/plain")}).status_code == 415
    assert c.post("/api/safety").status_code == 422

def test_valuation():
    body = dict(location="Bhopal", property_type="Apartment", area_sqft=1200, bedrooms=3, age_years=5,
                condition="good", amenities=["lift", "parking"])
    j = c.post("/api/valuation", json=body).json()
    assert j["range_low_inr"] < j["estimated_value_inr"] < j["range_high_inr"]

def test_planning():
    body = dict(project_name="Villa", project_type="Residential", location="Bhopal", built_up_area_sqft=2000,
                floors=2, budget_inr=6000000, duration_months=10, notes="")
    j = c.post("/api/planning", json=body).json()
    assert abs(sum(x["percent"] for x in j["cost_breakdown"]) - 100) < 0.01

def test_assistant_and_knowledge():
    r = c.post("/api/assistant", data=dict(site_name="Site A", work_done="Slab shuttering done. Rebar placed",
                                           workers_present=20))
    assert r.status_code == 200
    assert c.post("/api/knowledge", json={"question": "Curing period for OPC concrete?"}).status_code == 200
    assert c.post("/api/knowledge", json={"question": " "}).status_code == 422
