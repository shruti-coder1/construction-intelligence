# Multimodal Construction Intelligence Platform

An AI decision-support system for construction teams. A React frontend talks to a FastAPI backend, which sends text and images to a multimodal LLM (Google Gemini) and returns **strict JSON** that the UI renders.

## Features
| Module | Endpoint | Input | Output contract |
|---|---|---|---|
| Site safety monitoring | `POST /api/safety` | photo + context | `SafetyReport` (score, risk, PPE, violations) |
| Crack detection & analysis | `POST /api/cracks` | photo + context | `CrackReport` (type, width, causes, repairs) |
| Real estate valuation | `POST /api/valuation` | JSON | `ValuationReport` (value, range, factors) |
| Construction planning | `POST /api/planning` | JSON | `PlanReport` (phases, costs, materials, risks) |
| Daily site assistant | `POST /api/assistant` | notes + optional photo | `DailyReport` |
| Weather-aware advisory | `POST /api/weather` | city, activity | live Open-Meteo forecast + `WeatherAdvisory` |
| Construction knowledge assistant | `POST /api/knowledge` | question + history | `KnowledgeAnswer` |
| Health | `GET /api/health` | | `{status, mode}` (`live` or `demo`) |

All contracts live in `backend/app/schemas.py`. Gemini is called with `response_schema`, the reply is validated with Pydantic (one retry), and FastAPI's `response_model` guarantees the frontend never receives a malformed shape.

## Run locally
**Backend** (Python 3.9+)
```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # add GEMINI_API_KEY (free key: aistudio.google.com/apikey)
uvicorn app.main:app --reload --port 8000
```
No key? Leave it empty: the app runs in **demo mode** with sample responses (weather is still live). API docs: http://localhost:8000/docs

**Frontend** (Node 18+)
```bash
cd frontend
npm install
npm run dev                                            # http://localhost:5173 (proxies /api to :8000)
```

**Tests:** `cd backend && pytest`

## Deploy (to get your Demo link)
- **Backend:** Render / Railway / Cloud Run. Start command `uvicorn app.main:app --host 0.0.0.0 --port $PORT`, root `backend`. Set `GEMINI_API_KEY` and `CORS_ORIGINS=https://<your-frontend-url>`.
- **Frontend:** Vercel / Netlify. Root `frontend`, build `npm run build`, output `dist`, env `VITE_API_URL=https://<your-backend-url>/api`.

## Project structure
```
backend/app/   main.py (routes) · schemas.py (JSON contracts) · prompts.py · llm.py (Gemini + demo fallback) · weather.py · mocks.py
backend/tests/ test_api.py
frontend/src/  App.jsx · modules.jsx (form config) · reports.jsx (result renderers) · api.js · styles.css
```

## Notes
AI output is decision support, not an engineering sign-off. Crack and safety findings should be verified by a licensed engineer, and valuations are estimates, not appraisals.
