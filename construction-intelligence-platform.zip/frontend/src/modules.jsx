import { SafetyReport, CrackReport, ValuationReport, PlanReport, DailyReport, WeatherReport } from "./reports.jsx";

const today = new Date().toISOString().slice(0, 10);

// Each module = a form + an endpoint + a renderer for its JSON contract.
export const MODULES = [
  {
    id: "safety", title: "Site safety", blurb: "Upload a site photo to check PPE, edge protection, scaffolding and housekeeping.",
    endpoint: "/safety", multipart: true, image: "required", Render: SafetyReport, submit: "Check site safety",
    fields: [{ name: "context", label: "What is happening in the photo? (optional)", type: "textarea" }],
  },
  {
    id: "cracks", title: "Crack analysis", blurb: "Upload a close-up of a crack to classify it and get repair guidance.",
    endpoint: "/cracks", multipart: true, image: "required", Render: CrackReport, submit: "Analyse crack",
    fields: [{ name: "context", label: "Where is it, and how long has it been there? (optional)", type: "textarea" }],
  },
  {
    id: "valuation", title: "Property valuation", blurb: "Estimate market value from location, size, age and condition.",
    endpoint: "/valuation", Render: ValuationReport, submit: "Estimate value",
    fields: [
      { name: "location", label: "Location", def: "Bhopal, Madhya Pradesh" },
      { name: "property_type", label: "Property type", type: "select", options: ["Apartment", "Independent house", "Villa", "Plot with structure", "Commercial"], def: "Apartment" },
      { name: "area_sqft", label: "Area (sq ft)", type: "number", def: 1200 },
      { name: "bedrooms", label: "Bedrooms", type: "number", def: 3 },
      { name: "age_years", label: "Age (years)", type: "number", def: 5 },
      { name: "condition", label: "Condition", type: "select", options: ["Excellent", "Good", "Fair", "Needs repair"], def: "Good" },
      { name: "amenities", label: "Amenities (comma separated)", type: "list", def: "Lift, Parking, Security" },
    ],
  },
  {
    id: "planning", title: "Project planning", blurb: "Generate phases, cost breakdown, material quantities and risks.",
    endpoint: "/planning", Render: PlanReport, submit: "Build plan",
    fields: [
      { name: "project_name", label: "Project name", def: "Green Valley Residence" },
      { name: "project_type", label: "Project type", type: "select", options: ["Residential", "Commercial", "Industrial", "Renovation"], def: "Residential" },
      { name: "location", label: "Location", def: "Bhopal" },
      { name: "built_up_area_sqft", label: "Built-up area (sq ft)", type: "number", def: 2400 },
      { name: "floors", label: "Floors", type: "number", def: 2 },
      { name: "budget_inr", label: "Budget (₹)", type: "number", def: 6000000 },
      { name: "duration_months", label: "Target duration (months)", type: "number", def: 10 },
      { name: "notes", label: "Notes (optional)", type: "textarea", def: "" },
    ],
  },
  {
    id: "assistant", title: "Daily site report", blurb: "Turn rough site notes (and an optional photo) into a structured daily report.",
    endpoint: "/assistant", multipart: true, image: "optional", Render: DailyReport, submit: "Create report",
    fields: [
      { name: "site_name", label: "Site name", def: "Block A" },
      { name: "date", label: "Date", def: today },
      { name: "workers_present", label: "Workers present", type: "number", def: 20 },
      { name: "work_done", label: "Work done today", type: "textarea", def: "Shuttering for 2nd floor slab completed. Rebar tying 60% done." },
      { name: "issues", label: "Issues (optional)", type: "textarea", def: "" },
    ],
  },
  {
    id: "weather", title: "Weather advisory", blurb: "Live forecast turned into go / hold-off guidance for site activities.",
    endpoint: "/weather", Render: WeatherReport, submit: "Get advisory",
    fields: [
      { name: "city", label: "City", def: "Bhopal" },
      { name: "activity", label: "Planned activity (optional)", def: "Slab concreting" },
    ],
  },
];
