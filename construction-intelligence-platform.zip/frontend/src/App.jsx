import { useEffect, useRef, useState } from "react";
import { MODULES } from "./modules.jsx";
import { KnowledgeAnswer } from "./reports.jsx";
import { getJson, postForm, postJson } from "./api.js";

function Form({ mod, busy, onSubmit }) {
  const init = () => Object.fromEntries(mod.fields.map((f) => [f.name, f.def ?? ""]));
  const [v, setV] = useState(init);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);

  useEffect(() => { setV(init()); setFile(null); setPreview(null); }, [mod.id]);
  useEffect(() => {
    if (!file) return setPreview(null);
    const u = URL.createObjectURL(file); setPreview(u); return () => URL.revokeObjectURL(u);
  }, [file]);

  const submit = (e) => {
    e.preventDefault();
    const out = {};
    mod.fields.forEach((f) => {
      let x = v[f.name];
      if (f.type === "number") x = Number(x);
      if (f.type === "list") x = String(x).split(",").map((s) => s.trim()).filter(Boolean);
      out[f.name] = x;
    });
    onSubmit(out, file);
  };

  return (
    <form onSubmit={submit} className="form">
      {mod.image && (
        <label className="drop">
          {preview ? <img src={preview} alt="Selected upload" /> : <span>{mod.image === "required" ? "Choose a photo (JPG, PNG, WebP, up to 8 MB)" : "Attach a site photo (optional)"}</span>}
          <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setFile(e.target.files[0] || null)} />
        </label>
      )}
      {mod.fields.map((f) => (
        <label key={f.name}>
          <span>{f.label}</span>
          {f.type === "textarea" ? <textarea rows={3} value={v[f.name] ?? ""} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />
            : f.type === "select" ? <select value={v[f.name]} onChange={(e) => setV({ ...v, [f.name]: e.target.value })}>{f.options.map((o) => <option key={o}>{o}</option>)}</select>
            : <input type={f.type === "number" ? "number" : "text"} min={f.type === "number" ? 0 : undefined} step="any" required={f.type !== "list"} value={v[f.name] ?? ""} onChange={(e) => setV({ ...v, [f.name]: e.target.value })} />}
        </label>
      ))}
      <button className="btn" disabled={busy || (mod.image === "required" && !file)}>{busy ? "Working…" : mod.submit}</button>
    </form>
  );
}

function ModulePage({ mod }) {
  const [state, setState] = useState({ data: null, error: "", busy: false });
  useEffect(() => setState({ data: null, error: "", busy: false }), [mod.id]);

  const run = async (values, file) => {
    setState({ data: null, error: "", busy: true });
    try {
      let data;
      if (mod.multipart) {
        const fd = new FormData();
        Object.entries(values).forEach(([k, x]) => fd.append(k, x));
        if (file) fd.append("image", file);
        data = await postForm(mod.endpoint, fd);
      } else data = await postJson(mod.endpoint, values);
      setState({ data, error: "", busy: false });
    } catch (e) { setState({ data: null, error: e.message, busy: false }); }
  };

  const { Render } = mod;
  return (
    <div className="split">
      <div className="panel"><p className="blurb">{mod.blurb}</p><Form mod={mod} busy={state.busy} onSubmit={run} /></div>
      <div className="panel result" aria-live="polite">
        {state.busy && <p className="muted">Analysing. This usually takes a few seconds.</p>}
        {state.error && <p className="error">{state.error}</p>}
        {state.data && <Render d={state.data} />}
        {!state.busy && !state.error && !state.data && <p className="muted">Your report will appear here.</p>}
      </div>
    </div>
  );
}

function Knowledge() {
  const [turns, setTurns] = useState([]);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const end = useRef(null);
  useEffect(() => end.current?.scrollIntoView({ behavior: "smooth" }), [turns, busy]);

  const ask = async (e) => {
    e.preventDefault();
    if (!q.trim() || busy) return;
    const history = turns.flatMap((t) => [{ role: "user", content: t.q }, { role: "assistant", content: t.a.answer }]);
    const question = q; setQ(""); setBusy(true); setError("");
    try {
      const a = await postJson("/knowledge", { question, history });
      setTurns((t) => [...t, { q: question, a }]);
    } catch (err) { setError(err.message); setQ(question); }
    setBusy(false);
  };

  return (
    <div className="chat">
      <p className="blurb">Ask about materials, methods, codes, curing, estimating or site practice.</p>
      <div className="thread">
        {turns.length === 0 && <p className="muted">Try: “What is the minimum curing period for OPC concrete?”</p>}
        {turns.map((t, i) => (
          <div key={i}><div className="bubble me">{t.q}</div><div className="bubble bot"><KnowledgeAnswer d={t.a} /></div></div>
        ))}
        {busy && <div className="bubble bot muted">Thinking…</div>}
        {error && <p className="error">{error}</p>}
        <div ref={end} />
      </div>
      <form className="ask" onSubmit={ask}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask a construction question" aria-label="Question" />
        <button className="btn" disabled={busy || !q.trim()}>Ask</button>
      </form>
    </div>
  );
}

export default function App() {
  const all = [...MODULES, { id: "knowledge", title: "Knowledge assistant" }];
  const [active, setActive] = useState(all[0].id);
  const [mode, setMode] = useState(null);
  useEffect(() => { getJson("/health").then((h) => setMode(h.mode)).catch(() => setMode("offline")); }, []);
  const mod = MODULES.find((m) => m.id === active);

  return (
    <div className="app">
      <header className="top">
        <div className="tape" aria-hidden="true" />
        <div className="topbar">
          <h1>Construction Intelligence</h1>
          <span className={`mode mode-${mode}`}>{mode === "live" ? "Live AI" : mode === "demo" ? "Demo mode: sample responses" : mode === "offline" ? "Backend not reachable" : "Connecting…"}</span>
        </div>
      </header>
      <div className="body">
        <nav className="nav" aria-label="Modules">
          {all.map((m) => <button key={m.id} className={m.id === active ? "on" : ""} onClick={() => setActive(m.id)}>{m.title}</button>)}
        </nav>
        <main>
          <h2>{all.find((m) => m.id === active).title}</h2>
          {mod ? <ModulePage mod={mod} /> : <Knowledge />}
        </main>
      </div>
    </div>
  );
}
