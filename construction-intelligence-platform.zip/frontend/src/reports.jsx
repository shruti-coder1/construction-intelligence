// Renderers for each JSON contract returned by the backend.
const inr = (n) => "₹" + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 0 });

export const Badge = ({ level }) => <span className={`badge sev-${level}`}>{level}</span>;
const List = ({ items }) =>
  items?.length ? <ul className="plain">{items.map((x, i) => <li key={i}>{x}</li>)}</ul> : <p className="muted">None reported.</p>;
const Block = ({ title, children }) => <section className="block"><h4>{title}</h4>{children}</section>;
const Stat = ({ label, value, sub }) => (
  <div className="stat"><span className="stat-label">{label}</span><strong>{value}</strong>{sub && <small>{sub}</small>}</div>
);

export function SafetyReport({ d }) {
  return (<>
    <div className="stats">
      <Stat label="Safety score" value={`${d.safety_score}/100`} />
      <div className="stat"><span className="stat-label">Overall risk</span><Badge level={d.overall_risk} /></div>
    </div>
    <p>{d.summary}</p>
    <Block title="PPE detected"><List items={d.ppe_detected} /></Block>
    <Block title="Violations">
      {d.violations.length ? d.violations.map((v, i) => (
        <div className="item" key={i}>
          <div className="item-head"><strong>{v.issue}</strong><Badge level={v.severity} /></div>
          <small className="muted">{v.location}</small>
          <p>{v.recommendation}</p>
        </div>)) : <p className="muted">No violations found.</p>}
    </Block>
    <Block title="Recommendations"><List items={d.recommendations} /></Block>
  </>);
}

export function CrackReport({ d }) {
  return (<>
    <div className="stats">
      <div className="stat"><span className="stat-label">Crack found</span><strong>{d.crack_detected ? "Yes" : "No"}</strong></div>
      <Stat label="Type" value={d.crack_type} />
      <Stat label="Width" value={`${d.estimated_width_mm} mm`} />
      <div className="stat"><span className="stat-label">Severity</span><Badge level={d.severity} /></div>
    </div>
    <p>{d.summary}</p>
    <Block title="Affected element"><p>{d.affected_element}</p></Block>
    <Block title="Structural risk"><p>{d.structural_risk}</p></Block>
    <Block title="Probable causes"><List items={d.probable_causes} /></Block>
    <Block title="Repair recommendations"><List items={d.repair_recommendations} /></Block>
    <Block title="Urgency"><p>{d.urgency}</p></Block>
  </>);
}

export function ValuationReport({ d }) {
  return (<>
    <div className="stats">
      <Stat label="Estimated value" value={inr(d.estimated_value_inr)} sub={`${inr(d.range_low_inr)} to ${inr(d.range_high_inr)}`} />
      <Stat label="Per sq ft" value={inr(d.price_per_sqft_inr)} />
      <Stat label="Confidence" value={d.confidence} />
    </div>
    <p>{d.summary}</p>
    <Block title="What moves the price">
      {d.factors.map((f, i) => (
        <div className="item" key={i}>
          <div className="item-head"><strong>{f.name}</strong><span className={`badge imp-${f.impact}`}>{f.impact}</span></div>
          <p>{f.explanation}</p>
        </div>))}
    </Block>
    <Block title="Market outlook"><p>{d.market_outlook}</p></Block>
  </>);
}

export function PlanReport({ d }) {
  return (<>
    <div className="stats">
      <Stat label="Duration" value={`${d.total_duration_weeks} weeks`} />
      <Stat label="Estimated cost" value={inr(d.total_estimated_cost_inr)} sub={d.budget_status} />
    </div>
    <p>{d.summary}</p>
    <Block title="Phases">
      {d.phases.map((p, i) => (
        <div className="item" key={i}>
          <div className="item-head"><strong>{p.name}</strong><span className="muted">{p.duration_weeks} wk</span></div>
          <List items={p.tasks} />
          <small className="muted">Milestone: {p.milestone}</small>
        </div>))}
    </Block>
    <Block title="Cost breakdown">
      {d.cost_breakdown.map((c, i) => (
        <div className="bar-row" key={i}>
          <span>{c.category}</span>
          <div className="bar"><i style={{ width: `${Math.min(100, c.percent)}%` }} /></div>
          <span>{c.percent}% · {inr(c.amount_inr)}</span>
        </div>))}
    </Block>
    <Block title="Materials">
      <table><tbody>{d.materials.map((m, i) => <tr key={i}><td>{m.item}</td><td>{m.quantity.toLocaleString("en-IN")} {m.unit}</td></tr>)}</tbody></table>
    </Block>
    <Block title="Risks">
      {d.risks.map((r, i) => <div className="item" key={i}><strong>{r.risk}</strong><p>{r.mitigation}</p></div>)}
    </Block>
  </>);
}

export function DailyReport({ d }) {
  return (<>
    <div className="stats"><Stat label="Progress today" value={`${d.progress_estimate_percent}%`} /></div>
    <p>{d.summary}</p>
    <Block title="Completed"><List items={d.completed_items} /></Block>
    <Block title="Pending"><List items={d.pending_items} /></Block>
    <Block title="Issues"><List items={d.issues} /></Block>
    <Block title="Safety notes"><List items={d.safety_notes} /></Block>
    <Block title="Resources needed"><List items={d.resource_needs} /></Block>
    <Block title="Plan for tomorrow"><List items={d.next_day_plan} /></Block>
  </>);
}

export function WeatherReport({ d }) {
  const a = d.advisory;
  return (<>
    <h3 className="loc">{d.location}</h3>
    <div className="stats">
      <Stat label="Now" value={`${d.current.temperature_c}°C`} sub={d.current.condition} />
      <Stat label="Humidity" value={`${d.current.humidity_pct}%`} />
      <Stat label="Wind" value={`${d.current.wind_kmh} km/h`} />
      <div className="stat"><span className="stat-label">Work suitability</span><strong>{a.work_suitability}</strong><Badge level={a.risk_level} /></div>
    </div>
    <p>{a.summary}</p>
    <Block title="Five-day outlook">
      <div className="scroll"><table>
        <thead><tr><th>Date</th><th>Sky</th><th>Min / Max</th><th>Rain</th><th>Wind</th></tr></thead>
        <tbody>{d.daily.map((x) => (
          <tr key={x.date}><td>{x.date}</td><td>{x.condition}</td><td>{x.temp_min_c}° / {x.temp_max_c}°</td><td>{x.rain_mm} mm</td><td>{x.wind_max_kmh} km/h</td></tr>))}
        </tbody></table></div>
    </Block>
    <Block title="Good to do"><List items={a.recommended_activities} /></Block>
    <Block title="Hold off on"><List items={a.activities_to_avoid} /></Block>
    <Block title="Precautions"><List items={a.precautions} /></Block>
  </>);
}

export function KnowledgeAnswer({ d }) {
  return (<>
    <p>{d.answer}</p>
    {d.key_points?.length > 0 && <List items={d.key_points} />}
    {d.related_topics?.length > 0 && <p className="chips">{d.related_topics.map((t) => <span key={t}>{t}</span>)}</p>}
    <small className="muted">{d.caution}</small>
  </>);
}
