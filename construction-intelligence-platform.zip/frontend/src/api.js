const BASE = import.meta.env.VITE_API_URL || "/api";

async function handle(r) {
  if (!r.ok) {
    let msg = `Request failed (${r.status})`;
    try {
      const j = await r.json();
      msg = typeof j.detail === "string" ? j.detail : j.detail ? "Some fields are missing or invalid." : msg;
    } catch { /* keep default */ }
    throw new Error(msg);
  }
  return r.json();
}

export const getJson = (p) => fetch(BASE + p).then(handle);
export const postJson = (p, body) =>
  fetch(BASE + p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(handle);
export const postForm = (p, fd) => fetch(BASE + p, { method: "POST", body: fd }).then(handle);
